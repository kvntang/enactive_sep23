import serial #add serial library for serial communication
import time

# Open serial port, make sure to verify your arduino port number
serialcomm = serial.Serial('COM3', 9600)
serialcomm.timeout = 1

while True:

    i = input("Light Inputs [on/off]: ").strip()
    if i == "Done":
        print('finished')
        break
    
    serialcomm.write(i.encode())
    time.sleep(0.5)
    print(serialcomm.readline().decode('ascii'))

serialcomm.close()