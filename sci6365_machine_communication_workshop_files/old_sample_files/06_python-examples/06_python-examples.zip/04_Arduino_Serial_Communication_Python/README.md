Python Code to run Serial Communication with Arduino
Example file: Light on / off

## Installation 

```
pip install pyserial
```
This python serial library is required for serial communication (https://pypi.org/project/pyserial/) 

### Set Up 

```
serialcomm = serial.Serial('COM3', 9600)
```
In '04_Arduino_Serial_Communication.py', verify that the port number matches arduino port (ex. COM4). 

Verify + upload arduino code to your Arduino, then run python code & enjoy!
