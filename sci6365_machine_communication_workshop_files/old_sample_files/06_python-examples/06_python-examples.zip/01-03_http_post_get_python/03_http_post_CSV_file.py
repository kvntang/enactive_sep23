import requests

# We will be using https://httpbin.org/ for this example

url = 'https://httpbin.org/post'

#Post Single File
#Note: file handling is set as r = read & b = binary (reccomended); Info: https://www.w3schools.com/python/python_file_handling.asp
files = {'file': open('Sample_zillow.csv', 'rb')}
r = requests.post(url, files=files)

#Post Multiple Files
#files = [
#    ('copy1', ('zillow.csv'), open('zillow.csv', 'rb')),
#    ('copy2', ('zillow.csv'), open('zillow.csv', 'rb'))
#        ]

print(r.status_code)
print(r.text)
