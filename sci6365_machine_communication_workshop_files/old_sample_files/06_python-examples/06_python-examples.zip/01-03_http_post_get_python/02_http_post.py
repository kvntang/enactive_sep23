import requests

# We will be using https://httpbin.org/ for this example

# Post the data from the API
# payload = {"key1": "value1", "key2": "value2"}
payload = {"firstName": "Joe", "lastName": "Roe"}
r = requests.post("https://httpbin.org/post", data=payload)

# Print keys and strings from payload dictionary have been URL encoded 
print(r.url)

# Print HTTP response code. Useful website to verify different HTTP response codes: https://developer.mozilla.org/en-US/docs/Web/HTTP/Status#successful_responses)
print(r.status_code)

# Print HTTP post content
print(r.text) 
# or print(r.content)