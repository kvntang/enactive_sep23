import requests
import argparse

#initiate the parser
parser = argparse.ArgumentParser()
parser.add_argument("-u", "--url", help="URL to send request to")
parser.add_argument("-p", "--params", help="Parameters to send with request in format: '{key1: value1, key2: value2}'")

#read arguments from the command line
args = parser.parse_args()

#check for --url or -u
if args.url:
    url = args.url
else:
    url = "https://httpbin.org/"
    params = {"firstName": "Joe", "lastName": "Doe"}

#check for --parameters or -p
if args.params:
    params = args.params
else:
    params = ''

# Make a GET request of data from the API
r = requests.get(url, params)

#Troubleshooting message
if r.status_code != 200:
    print("Error: " + str(r.status_code) + "Try to set parameter input as '{key1: value1, key2: value2}'")
    exit()

# Print HTTP response code. Useful website to verify different HTTP response codes: https://developer.mozilla.org/en-US/docs/Web/HTTP/Status#successful_responses)
print(r.status_code)

# Print keys and strings from payload dictionary that have been URL encoded
print(r.url)
    
# Print HTTP response content (alternatively print(r.content))
print(r.text)








