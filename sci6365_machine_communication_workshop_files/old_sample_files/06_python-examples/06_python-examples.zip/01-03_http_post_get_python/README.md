README for Python GET & POST Request Examples

### 01_http_get.py
 
For this excercise we will use Python's 'argparse' module and use it to build a simple-command line tool for HTTP GET requests. Here are some command line inputs that can be used:

```
python http_get.py 
```

This will run a default get request from "https://httpbin.org/" with parameters {"firstName": "Joe", "lastName": "Doe"}

```
python http_get.py --help
```

This will provide information about the input arguments.
 
```
python http_get.py --url https://api-v3.mbta.com/stops/place-harsq
```

The code includes arguments you can manipulate. In this case it will download the json without parameters.

```
python http_get.py --url https://www.youtube.com/watch --params '{"v": "tgtb9iucOts", "t": "531s"}'
```

Downloads the html for this particular video.


### 02_http_post.py & 03_http_post_CSV_file.py
 
For this example we will be posting parameters in the form of a dictionary : {"key1": "value1", "key2": "value2"} to https://httpbin.org/ .

You can post different data or file formats. For example in 03_http_post_CSV_se the 'Sample_zillow.csv' to test posting a csv file. 

Enjoy!